from resources.lib.vtele import Main

Main()