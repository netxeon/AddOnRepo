# The XBMC *Tagesschau* Addon

This is the repository for the *XBMC Tagesschau Plugin*.
[XBMC](http://xbmc.org) is a famous media center software. This
plugin enables you to access video content from
[tagesschau.de](http://tagesschau.de) from within XBMC.


## Bugs

If you find a bug, please either 

  * submit it to GitHub's [bug
    tracker](https://github.com/joerns/xbmc-plugin.video.tagesschau/issues),
  * or write me an E-Mail to qjoern at-the-domain gmail.com.


## Contributors

  - [Jörn Schumacher](https://github.com/joerns/)
  - [Henning Saul](https://github.com/henningSaul)

