# -*- coding: iso-8859-1 -*-
""" crypto.entropy

    Entropy package of CryptoPy

    Copyright � (c) 2002 by Paul A. Lambert
    Read LICENSE.txt for license information.
"""

