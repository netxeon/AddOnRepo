#Funimation XBMC Plugin

An XBMC plugin for streaming videos from funimation.com.

If you're interested in helping out, just drop me an email or send a pull
request. Patches and (constructive) input are always welcome.

Todo
----
+ implement a "My Watchlist"
+ get show icons from different site
+ context menu for getting show details
