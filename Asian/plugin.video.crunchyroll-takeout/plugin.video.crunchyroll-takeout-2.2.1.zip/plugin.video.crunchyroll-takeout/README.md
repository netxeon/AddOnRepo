Crunchyroll plugin for Kodi
==========

Crunchyroll
A KODI (XBMC) plugin for Cruchyroll. 
This plugin a an amalgamation of some of my own code and other's patches.

Git Repo: https://github.com/Yoshiofthewire/CrunchyXBMC

Legacy Builds: https://github.com/Yoshiofthewire/CrunchyXBMC-Legacy

Forum Posting: http://forum.kodi.tv/showthread.php?tid=129709

Disclaimer:
You MUST be a Crunchyroll Premium Member!

Thanks to the following for code:

maruchan, Reinis, Eduardo, randomllama, Voinage, Zehd, mattrk, and le__
