# -*- coding: utf-8 -*-

languages = {
	"Espanol (Espana)": ("Spanish", "es", "ESP", 1),
	"Espanol (Latinoamerica)": ("Latino", "es", "ESP", 2),
	"English": ("English", "en", "ENG", 2),
	"French": ("French", "fr", "FRE", 2),
	"Italian": ("Italian", "it", "ITA", 2),
	"Unknown": ("Unknown", "-", "???", 3),
}
