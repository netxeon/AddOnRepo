service.subtitles.subtituloses
==============================
Subtitulos.es subtitle service plugin for XBMC
